python -c 'import yaml,pprint;pprint.pprint(yaml.load(open("test.yml").read()))'
